import React from 'react';

const Header = () => {
  return (
    <div className="welcome-header">
      <h1>Welcome to Real-Time Event Tracking System</h1>
    </div>
  );
};

export default Header;
