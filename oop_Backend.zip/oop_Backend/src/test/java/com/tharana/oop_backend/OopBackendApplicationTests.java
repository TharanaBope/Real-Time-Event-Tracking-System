package com.tharana.oop_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OopBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
