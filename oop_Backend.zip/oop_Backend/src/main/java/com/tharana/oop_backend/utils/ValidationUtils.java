package com.tharana.oop_backend.utils;

public class ValidationUtils {

    public static boolean isPositive(int value) {
        return value > 0;
    }
}
