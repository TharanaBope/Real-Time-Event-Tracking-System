package com.tharana.real_time_event_tracking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OopBackendRttsApplicationTests {

    @Test
    void contextLoads() {
    }

}
