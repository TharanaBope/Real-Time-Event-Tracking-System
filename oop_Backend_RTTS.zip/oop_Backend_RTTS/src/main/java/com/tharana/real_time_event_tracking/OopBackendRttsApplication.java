package com.tharana.real_time_event_tracking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OopBackendRttsApplication {

    public static void main(String[] args) {
        SpringApplication.run(OopBackendRttsApplication.class, args);
    }

}
